const quizData = [
    {
        name: "GEM",
        image: "https://www.pngmart.com/files/16/office-Animated-Businessman-PNG-Transparent-Image.png",
        dialogue: "In a small village, GEM is a farmer who grows just enough food for his family. One year, there was a drought, and his crops failed. GEM had two choices: sell his farmland to feed his family now or try to find another job that would help him earn enough to survive until next year's harvest.",
        questions: [
            {
                question: "What is the most sustainable decision GEM should make to avoid future poverty?",
                options: [
                    "Sell the land to feed his family immediately.",
                    "Borrow money to feed his family and keep farming.",
                    "Find temporary work and try to save the land.",
                    "Move to the city and work in a factory."
                ],
                correctAnswer: 2
            },
            {
                question: "How can the community help GEM and others like him prevent poverty during tough times?",
                options: [
                    "Provide short-term loans with low interest.",
                    "Build more factories for jobs.",
                    "Offer free meals to every family.",
                    "Encourage people to leave farming and move to cities."
                ],
                correctAnswer: 0
            }
        ]
    },
    {
        name: "MARIA",
        image: "https://cdni.iconscout.com/illustration/premium/thumb/rajasthani-woman-carrying-clay-water-pots-2790997-2334992.png",
        dialogue: "Maria is a bright student who dreams of becoming a doctor to help her village. However, her family is poor, and they cannot afford to send her to school beyond the basic education level. There is a scholarship available, but Maria must pass a very difficult exam.",
        questions: [
            {
                question: "What should Maria focus on to break the cycle of poverty in her family?",
                options: [
                    "Help her family at home instead of going to school.",
                    "Work hard to win the scholarship and continue her studies.",
                    "Ask her parents to move to a city where there are more opportunities.",
                    "Marry into a wealthier family."
                ],
                correctAnswer: 1
            },
            {
                question: "How can governments ensure that children like Maria have equal access to education?",
                options: [
                    "Create more scholarships only for top students.",
                    "Offer free, high-quality education to everyone.",
                    "Build private schools in every village.",
                    "Encourage children to work from an early age."
                ],
                correctAnswer: 1
            }
        ]
    },
    {
        name: "SERGIO",
        image: "https://webstockreview.net/images/fisherman-clipart-community-helper-5.png",
        dialogue: "SERGIO is a fisherman who has been catching fewer fish every year due to pollution in the river. His income has drastically decreased, and he is now considering taking a loan to buy better fishing equipment or switching to a different trade altogether.",
        questions: [
            {
                question: "What is the best way for SERGIO to ensure a long-term income?",
                options: [
                    "Buy better fishing equipment.",
                    "Take a second job in the city while continuing to fish.",
                    "Stop fishing and switch to a new trade.",
                    "Organize a community project to clean the river and increase fish numbers."
                ],
                correctAnswer: 3
            },
            {
                question: "How can the local government help people like SERGIO avoid poverty caused by environmental issues?",
                options: [
                    "Provide free fishing equipment.",
                    "Encourage people to leave fishing and find new jobs.",
                    "Offer training programs for other industries.",
                    "Implement policies to reduce pollution and help restore natural resources."
                ],
                correctAnswer: 3
            }
        ]
    },
    {
        name: "RAY",
        image: "https://www.pinclipart.com/picdir/big/134-1348678_woman-presentation-business-woman-png-image-vector-business.png",
        dialogue: "RAY has started a small business making handicrafts in her village. She hires several women from the village, providing them with a steady income. However, her business is struggling because she cannot afford to market her products outside the village, and the local demand is not enough.",
        questions: [
            {
                question: "What should RAY do to ensure her business can grow and lift more women out of poverty?",
                options: [
                    "Reduce her production to match local demand.",
                    "Take out a loan to market her products in nearby towns.",
                    "Raise the prices of her handicrafts to earn more money.",
                    "Fire some of her employees to reduce costs."
                ],
                correctAnswer: 1
            },
            {
                question: "How can communities support entrepreneurs like RAY to help fight poverty?",
                options: [
                    "Invest in local businesses and create cooperatives.",
                    "Only buy products from big companies.",
                    "Encourage people to move to cities for better opportunities.",
                    "Build more shops to sell RAY's handicrafts in the village."
                ],
                correctAnswer: 0
            }
        ]
    },
    {
        name: "DRAKE",
        image: "https://static.vecteezy.com/system/resources/previews/032/187/750/non_2x/employees-and-office-workers-cartoon-characters-free-png.png",
        dialogue: "In a large city, a neighborhood is filled with poorly constructed houses, and the people living there struggle to find steady jobs. The city government plans to tear down the slum and build new apartments. However, the residents fear they will not be able to afford to live in the new buildings.",
        questions: [
            {
                question: "What should the government prioritize to help the people in this slum escape poverty?",
                options: [
                    "Provide free apartments to those who cannot afford them.",
                    "Build new homes but ensure that they remain affordable.",
                    "Evict the residents and encourage them to move to the countryside.",
                    "Offer temporary housing and jobs to the residents until they can afford new homes."
                ],
                correctAnswer: 1
            },
            {
                question: "How can businesses and non-profit organizations help reduce poverty in such urban areas?",
                options: [
                    "Hire people from slum areas and provide skill development programs.",
                    "Donate large sums of money to the government.",
                    "Build luxury homes nearby to attract tourists and wealthy residents.",
                    "Move their factories to the slums and offer jobs at lower wages."
                ],
                correctAnswer: 0
            }
        ]
    }
];

let currentCharacter = 0;
let currentQuestion = 0;
let score = 0;

const startScreen = document.getElementById('start-screen');
const quizContainer = document.getElementById('quiz-container');
const resultsScreen = document.getElementById('results-screen');
const startButton = document.getElementById('start-button');
const nextButton = document.getElementById('next-button');
const replayButton = document.getElementById('replay-button');
const characterImage = document.getElementById('character-image');
const dialogueBox = document.getElementById('dialogue-box');
const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');
const scoreDisplay = document.getElementById('score-display');

startButton.addEventListener('click', startQuiz);
nextButton.addEventListener('click', nextQuestion);
replayButton.addEventListener('click', restartQuiz);

function startQuiz() {
    startScreen.style.display = 'none';
    quizContainer.style.display = 'block';
    loadCharacter();
}

function loadCharacter() {
    const character = quizData[currentCharacter];
    characterImage.style.backgroundImage = `url(${character.image})`;
    dialogueBox.textContent = character.dialogue;
    loadQuestion();
}

function loadQuestion() {
    const character = quizData[currentCharacter];
    const question = character.questions[currentQuestion];
    questionText.textContent = question.question;
    optionsContainer.innerHTML = '';
    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.textContent = option;
        button.classList.add('option-button');
        button.addEventListener('click', () => selectAnswer(index));
        optionsContainer.appendChild(button);
    });
    nextButton.style.display = 'none';
}

function selectAnswer(selectedIndex) {
    const character = quizData[currentCharacter];
    const question = character.questions[currentQuestion];
    const buttons = optionsContainer.getElementsByTagName('button');
    
    for (let button of buttons) {
        button.disabled = true;
        if (Array.from(buttons).indexOf(button) === question.correctAnswer) {
            button.style.backgroundColor = 'green';
        }
    }
    
    if (selectedIndex === question.correctAnswer) {
        score++;
        buttons[selectedIndex].style.backgroundColor = 'green';
    } else {
        buttons[selectedIndex].style.backgroundColor = 'red';
    }
    
    nextButton.style.display = 'block';
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion >= quizData[currentCharacter].questions.length) {
        currentCharacter++;
        currentQuestion = 0;
        if (currentCharacter >= quizData.length) {
            showResults();
            return;
        }
        loadCharacter();
    } else {
        loadQuestion();
    }
}

function showResults() {
    quizContainer.style.display = 'none';
    resultsScreen.style.display = 'block';
    const totalQuestions = quizData.length * 2;
    scoreDisplay.textContent = `You scored ${score} out of ${totalQuestions}`;
}

function restartQuiz() {
    currentCharacter = 0;
    currentQuestion = 0;
    score = 0;
    resultsScreen.style.display = 'none';
    startScreen.style.display = 'block';
}

const button = document.getElementById('myButton');

button.addEventListener('mouseover', function() {
  this.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.5)';
});

button.addEventListener('mouseout', function() {
  this.style.boxShadow = 'none';
});