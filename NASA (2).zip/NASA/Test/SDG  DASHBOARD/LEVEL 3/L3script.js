const quizData = [
    {
        name: "AMY",
        image: "https://static.vecteezy.com/system/resources/previews/021/730/185/original/character-high-school-student-in-school-uniform-png.png",
        dialogue: "Amy is a high school student passionate about improving her school’s environment. She notices that many students often eat unhealthy snacks and lack awareness about nutrition. Amy wants to launch a campaign promoting healthy eating.",
        questions: [
            {
                question: "What should Amy's first step be to ensure her campaign reaches the most students?",
                options: [
                    "Only create posters and hang them in the cafeteria.",
                    "Collaborate with teachers and organize interactive nutrition workshops.",
                    "Ban unhealthy snacks without explaining why.",
                    "Focus solely on social media to spread her message."
                ],
                correctAnswer: 1
            },
            {
                question: "How can Amy make her campaign sustainable and ensure students continue making healthier choices?",
                options: [
                    "Host a one-time event and stop promoting healthy eating afterward.",
                    "Organize a 'Healthy Eating Challenge' with rewards for students who participate.",
                    "Only give out free fruits and vegetables once and never follow up.",
                    "Focus only on high-performing students."
                ],
                correctAnswer: 1
            }
        ]
    },
    {
        name: "JAMAL",
        image: "https://static.vecteezy.com/system/resources/previews/021/730/196/original/character-high-school-student-in-school-uniform-png.png",
        dialogue: "Jamal is concerned about his classmates' stress levels due to academic pressure. He wants to introduce a mental health support program in his school to help students manage stress and promote well-being.",
        questions: [
            {
                question: "What should Jamal prioritize to make the mental health initiative effective?",
                options: [
                    "Create an anonymous online space for students to share their struggles.",
                    "Force students to attend mandatory counseling sessions.",
                    "Ignore the issue and hope it improves.",
                    "Only focus on students with the highest grades."
                ],
                correctAnswer: 0
            },
            {
                question: "Which of the following steps can Jamal take to ensure long-term success of the program?",
                options: [
                    "Offer mental health awareness workshops and train peer counselors to support their classmates.",
                    "Only hold one event at the start of the year and do nothing afterward.",
                    "Encourage students to ignore their mental health until exams are over.",
                    "Rely solely on teachers to manage the mental health of students."
                ],
                correctAnswer: 0
            }
        ]
    },
    {
        name: "CARLOS",
        image: "https://png.pngtree.com/png-clipart/20230825/original/pngtree-male-teacher-cartoon-character-holding-a-pointer-and-speak-picture-image_8778249.png",
        dialogue: "Carlos lives in a rural community that struggles with access to clean drinking water. Many children are frequently sick due to waterborne diseases. Carlos wants to help his community by improving access to clean water.",
        questions: [
            {
                question: "What should Carlos do first to address the issue of contaminated water?",
                options: [
                    "Provide bottled water for a short-term solution.",
                    "Test the water sources in the community to identify the main contaminants.",
                    "Rely on rainwater alone without filtering it.",
                    "Tell the community to stop drinking water until a solution is found."
                ],
                correctAnswer: 1
            },
            {
                question: "Which long-term solution should Carlos advocate for to improve water access and reduce illness?",
                options: [
                    "Install water filtration systems and teach the community how to maintain them.",
                    "Only focus on improving one water source and ignore the rest.",
                    "Depend on external aid without involving the community in the solution.",
                    "Promote boiling water but not offer any other tools or education."
                ],
                correctAnswer: 0
            }
        ]
    },
    {
    name: "FATIMA",
    image: "https://static.vecteezy.com/system/resources/previews/019/841/420/original/flat-icon-with-african-american-cute-businesswoman-cartoon-character-in-office-style-smart-black-suit-and-crossed-arms-pose-png.png", // Update with appropriate image URL
    dialogue: "Fatima is determined to promote women's rights in her community. She faces many challenges in advocating for gender equality and wants to create awareness about women's empowerment.",
    questions: [
        {
            question: "What should Fatima do to effectively raise awareness about women's rights?",
            options: [
                "Conduct workshops to educate both men and women about gender equality.",
                "Only speak to women about their rights.",
                "Avoid discussing controversial topics.",
                "Focus only on social media campaigns."
            ],
            correctAnswer: 0
        },
        {
            question: "How can Fatima ensure her campaign leads to real change?",
            options: [
                "Create a supportive network that includes community leaders and influencers.",
                "Hold one event and then stop campaigning.",
                "Focus on criticizing the existing system without offering solutions.",
                "Only advocate for women's rights in her local area."
            ],
            correctAnswer: 0
        }
    ]
    },
{
    name: "LIAM",
    image: "https://www.engdict.com/data/dict/media/images_public/sir-00085179637504505348578051_normal.png", // You can replace this with the appropriate image link
    dialogue: "Liam is a tech-savvy student who notices that many of his peers are struggling with digital literacy. He wants to start a program to teach his classmates essential tech skills.",
    questions: [
        {
            question: "What is Liam's best first step to make his program successful?",
            options: [
                "Create a website and hope students sign up.",
                "Survey students to find out which skills they want to learn.",
                "Only focus on advanced tech topics.",
                "Ask teachers to refer students without offering incentives."
            ],
            correctAnswer: 1
        },
        {
            question: "How can Liam ensure the program remains beneficial over time?",
            options: [
                "Conduct regular feedback sessions to adapt the program.",
                "Only hold workshops once a year.",
                "Limit the program to students who already have tech skills.",
                "Focus only on the most popular topics and ignore others."
            ],
            correctAnswer: 0
        }
    ]
}
];

let currentCharacter = 0;
let currentQuestion = 0;
let score = 0;

const startScreen = document.getElementById('start-screen');
const quizContainer = document.getElementById('quiz-container');
const resultsScreen = document.getElementById('results-screen');
const startButton = document.getElementById('start-button');
const nextButton = document.getElementById('next-button');
const replayButton = document.getElementById('replay-button');
const characterImage = document.getElementById('character-image');
const dialogueBox = document.getElementById('dialogue-box');
const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');
const scoreDisplay = document.getElementById('score-display');

startButton.addEventListener('click', startQuiz);
nextButton.addEventListener('click', nextQuestion);
replayButton.addEventListener('click', restartQuiz);

function startQuiz() {
    startScreen.style.display = 'none';
    quizContainer.style.display = 'block';
    loadCharacter();
}

function loadCharacter() {
    const character = quizData[currentCharacter];
    characterImage.style.backgroundImage = `url(${character.image})`;
    dialogueBox.textContent = character.dialogue;
    loadQuestion();
}

function loadQuestion() {
    const character = quizData[currentCharacter];
    const question = character.questions[currentQuestion];
    questionText.textContent = question.question;
    optionsContainer.innerHTML = '';
    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.textContent = option;
        button.classList.add('option-button');
        button.addEventListener('click', () => selectAnswer(index));
        optionsContainer.appendChild(button);
    });
    nextButton.style.display = 'none';
}

function selectAnswer(selectedIndex) {
    const character = quizData[currentCharacter];
    const question = character.questions[currentQuestion];
    const buttons = optionsContainer.getElementsByTagName('button');
    
    for (let button of buttons) {
        button.disabled = true;
        if (Array.from(buttons).indexOf(button) === question.correctAnswer) {
            button.style.backgroundColor = 'green';
        }
    }
    
    if (selectedIndex === question.correctAnswer) {
        score++;
        buttons[selectedIndex].style.backgroundColor = 'green';
    } else {
        buttons[selectedIndex].style.backgroundColor = 'red';
    }
    
    nextButton.style.display = 'block';
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion >= quizData[currentCharacter].questions.length) {
        currentCharacter++;
        currentQuestion = 0;
        if (currentCharacter >= quizData.length) {
            showResults();
            return;
        }
        loadCharacter();
    } else {
        loadQuestion();
    }
}

function showResults() {
    quizContainer.style.display = 'none';
    resultsScreen.style.display = 'block';
    const totalQuestions = quizData.length * 2;
    scoreDisplay.textContent = `You scored ${score} out of ${totalQuestions}`;
}

function restartQuiz() {
    currentCharacter = 0;
    currentQuestion = 0;
    score = 0;
    resultsScreen.style.display = 'none';
    startScreen.style.display = 'block';
}
