const quizData = [
    {
        name: "Cara",
        image: "https://static.vecteezy.com/system/resources/previews/019/834/625/original/flat-icon-with-african-american-cute-businesswoman-cartoon-character-in-office-style-smart-black-suit-and-crossed-arms-pose-png.png",
        dialogue: "A local community decides to start a garden to provide fresh vegetables to families in need. They have limited resources and must decide how to allocate their funds and volunteers effectively.",
        questions: [
            {
                question: "What is the best initial step for the community to take in starting the garden?",
                options: [
                    "Purchase all seeds and equipment immediately.",
                    "Survey the community to determine which vegetables are most needed.",
                    "Start planting without planning.",
                    "Focus solely on building a fence around the garden."
                ],
                correctAnswer: 1
            },
            {
                question: "To ensure the garden is sustainable, which of the following practices should the community adopt?",
                options: [
                    "Use chemical fertilizers exclusively for faster growth.",
                    "Teach families how to maintain the garden and grow their own food.",
                    "Only grow vegetables that require a lot of water.",
                    "Ignore seasonal changes and plant the same crops every time."
                ],
                correctAnswer: 1
            }
        ]
    },
    {
        name: "Aaron",
        image: "https://pngimg.com/uploads/student/student_PNG62542.png",
        dialogue: "A non-profit organization has received a large donation of food but lacks the means to distribute it effectively. They must find a way to get the food to those in need.",
        questions: [
            {
                question: "Which strategy should the organization prioritize to distribute the food quickly and effectively?",
                options: [
                    "Store the food in a warehouse until they can distribute it all at once.",
                    "Collaborate with local food banks and community centers for distribution.",
                    "Ask for more donations before distributing anything.",
                    "Post on social media to let people know they have food available."
                ],
                correctAnswer: 1
            },
            {
                question: "What method can the organization use to ensure that the food reaches the most vulnerable populations?",
                options: [
                    "Limit distribution to those who can physically come to pick up food.",
                    "Conduct outreach to identify families and individuals who need assistance.",
                    "Only distribute food to families with children.",
                    "Rely on volunteers to distribute food randomly."
                ],
                correctAnswer: 1
            }
        ]
    },
    {
        name: "Elena",
        image: "http://clipart-library.com/images_k/college-clipart-transparent/college-clipart-transparent-18.png",
        dialogue: "A high school wants to implement a meal program to provide nutritious lunches to students. They face challenges in funding and menu planning.",
        questions: [
            {
                question: "What should the school prioritize when creating the meal plan?",
                options: [
                    "Include only popular fast food items to encourage students to participate.",
                    "Focus on nutritious options that reflect the dietary needs of students.",
                    "Create an expensive gourmet menu to impress parents.",
                    "Use the same menu every week to save time."
                ],
                correctAnswer: 1
            },
            {
                question: "To secure funding for the meal program, which approach should the school take?",
                options: [
                    "Organize a fundraising event involving the community.",
                    "Cut other educational programs to allocate more funds.",
                    "Wait for the government to provide assistance.",
                    "Ask students to pay high prices for meals."
                ],
                correctAnswer: 0
            }
        ]
    },
    {
        name: "David",
        image: "https://static.vecteezy.com/system/resources/previews/017/745/733/large_2x/illustration-of-cartoon-businessman-standing-in-suit-with-finger-pointing-on-blank-screen-free-png.png",
        dialogue: "A local restaurant wants to reduce food waste and contribute to the Zero Hunger goal. They are brainstorming initiatives to implement.",
        questions: [
            {
                question: "What is the most effective way for the restaurant to start reducing food waste?",
                options: [
                    "Donate leftover food to local shelters and food banks.",
                    "Throw away all leftovers to avoid contamination.",
                    "Serve larger portions to avoid complaints.",
                    "Reduce the number of items on the menu to minimize leftovers."
                ],
                correctAnswer: 0
            },
            {
                question: "Which practice can help the restaurant further minimize food waste?",
                options: [
                    "Track inventory and adjust purchasing based on sales.",
                    "Offer discounts on large portions to attract more customers.",
                    "Increase portion sizes across all dishes.",
                    "Ignore food waste and focus solely on customer satisfaction."
                ],
                correctAnswer: 0
            }
        ]
    }
];

let currentCharacter = 0;
let currentQuestion = 0;
let score = 0;

const startScreen = document.getElementById('start-screen');
const quizContainer = document.getElementById('quiz-container');
const resultsScreen = document.getElementById('results-screen');
const startButton = document.getElementById('start-button');
const nextButton = document.getElementById('next-button');
const replayButton = document.getElementById('replay-button');
const characterImage = document.getElementById('character-image');
const dialogueBox = document.getElementById('dialogue-box');
const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');
const scoreDisplay = document.getElementById('score-display');

startButton.addEventListener('click', startQuiz);
nextButton.addEventListener('click', nextQuestion);
replayButton.addEventListener('click', restartQuiz);

function startQuiz() {
    startScreen.style.display = 'none';
    quizContainer.style.display = 'block';
    loadCharacter();
}

function loadCharacter() {
    const character = quizData[currentCharacter];
    characterImage.style.backgroundImage = `url(${character.image})`;
    dialogueBox.textContent = character.dialogue;
    loadQuestion();
}

function loadQuestion() {
    const character = quizData[currentCharacter];
    const question = character.questions[currentQuestion];
    questionText.textContent = question.question;
    optionsContainer.innerHTML = '';
    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.textContent = option;
        button.classList.add('option-button');
        button.addEventListener('click', () => selectAnswer(index));
        optionsContainer.appendChild(button);
    });
    nextButton.style.display = 'none';
}

function selectAnswer(selectedIndex) {
    const character = quizData[currentCharacter];
    const question = character.questions[currentQuestion];
    const buttons = optionsContainer.getElementsByTagName('button');
    
    for (let button of buttons) {
        button.disabled = true;
        if (Array.from(buttons).indexOf(button) === question.correctAnswer) {
            button.style.backgroundColor = 'green';
        }
    }
    
    if (selectedIndex === question.correctAnswer) {
        score++;
        buttons[selectedIndex].style.backgroundColor = 'green';
    } else {
        buttons[selectedIndex].style.backgroundColor = 'red';
    }
    
    nextButton.style.display = 'block';
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion >= quizData[currentCharacter].questions.length) {
        currentCharacter++;
        currentQuestion = 0;
        if (currentCharacter >= quizData.length) {
            showResults();
            return;
        }
        loadCharacter();
    } else {
        loadQuestion();
    }
}

function showResults() {
    quizContainer.style.display = 'none';
    resultsScreen.style.display = 'block';
    const totalQuestions = quizData.length * 2;
    scoreDisplay.textContent = `You scored ${score} out of ${totalQuestions}`;
}

function restartQuiz() {
    currentCharacter = 0;
    currentQuestion = 0;
    score = 0;
    resultsScreen.style.display = 'none';
    startScreen.style.display = 'block';
}
