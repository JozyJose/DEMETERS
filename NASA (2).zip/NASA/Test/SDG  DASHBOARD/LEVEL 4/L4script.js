const quizData = [
    {
        name: "DANIEL",
        image: "https://www.pinclipart.com/picdir/big/136-1368958_professor-cartoon-png-transparent-clipart.png",
        dialogue: "Daniel notices that students in his school have different learning styles and abilities, yet the current teaching methods do not cater to these differences. He wants to create a program that offers personalized learning opportunities for everyone.",
        questions: [
            {
                question: "What should Daniel's first step be to make sure his program helps the most students?",
                options: [
                    "Offer the same teaching method to all students regardless of their needs.",
                    "Identify the different learning styles of students and work with teachers to create flexible lesson plans.",
                    "Only focus on students who are struggling academically.",
                    "Create a program that requires students to learn faster than their usual pace."
                ],
                correctAnswer: 1
            },
            {
                question: "How can Daniel ensure the program remains beneficial for all students over time?",
                options: [
                    "Regularly assess the students' progress and adjust the learning methods accordingly.",
                    "Only provide help for one semester and then stop.",
                    "Focus only on students with special needs, ignoring others.",
                    "Make it mandatory for all students to attend extra classes after school."
                ],
                correctAnswer: 0
            }
        ]
    },
    {
        name: "LEILA",
        image: "https://webstockreview.net/images/teen-clipart-confident-student-8.png",
        dialogue: "Leila realizes that some of her classmates do not have access to computers or the internet at home, which affects their ability to complete assignments. She wants to start an initiative to improve digital literacy and ensure everyone has access to technology.",
        questions: [
            {
                question: "What should Leila focus on first to ensure that her initiative is successful?",
                options: [
                    "Provide students with free lessons on using digital tools and online resources.",
                    "Ignore the issue and assume students will figure it out on their own.",
                    "Only teach advanced computer programming without covering the basics.",
                    "Focus only on students who already have computers at home."
                ],
                correctAnswer: 0
            },
            {
                question: "What is a long-term solution Leila can work towards to ensure all students have access to technology?",
                options: [
                    "Partner with local organizations to provide affordable or donated computers and internet access to students.",
                    "Only focus on students from wealthier families who can afford their own devices.",
                    "Limit the initiative to offering lessons, without addressing the access problem.",
                    "Stop the initiative after teaching the basics once."
                ],
                correctAnswer: 0
            }
        ]
    },
    {
        name: "SAM",
        image: "https://static.vecteezy.com/system/resources/previews/025/003/244/large_2x/3d-cute-cartoon-female-teacher-character-on-transparent-background-generative-ai-png.png",
        dialogue: "Sam has noticed that teachers in his school often struggle with large class sizes and limited resources, which affects their ability to provide quality education to all students. He wants to start a support network for teachers to share resources and strategies.",
        questions: [
            {
                question: "What should be Sam’s first action to create an effective teacher support network?",
                options: [
                    "Create a platform where teachers can collaborate, share lesson plans, and discuss challenges.",
                    "Focus only on students and ignore the needs of the teachers.",
                    "Ask teachers to stay after school every day for extra meetings.",
                    "Provide teachers with complicated and time-consuming resources."
                ],
                correctAnswer: 0
            },
            {
                question: "How can Sam ensure that the support network continues to be useful for teachers?",
                options: [
                    "Organize regular workshops and encourage teachers to give feedback and suggest improvements.",
                    "Make it a one-time event and forget about it.",
                    "Focus only on theoretical resources without practical applications.",
                    "Limit participation to only a few teachers."
                ],
                correctAnswer: 0
            }
        ]
    },
    {
        name: "ALISHA",
        image: "https://static.vecteezy.com/system/resources/previews/019/836/766/original/flat-icon-with-businesswoman-cartoon-character-in-office-style-smart-suit-and-crossed-arms-pose-png.png",
        dialogue: "Alisha is passionate about helping her peers understand difficult subjects. She has started a peer tutoring group to assist students who are struggling academically.",
        questions: [
            {
                question: "What should Alisha do first to ensure her tutoring group is effective?",
                options: [
                    "Only help students who are failing.",
                    "Create a welcoming environment where all students feel comfortable asking for help.",
                    "Limit the group size to only a few students.",
                    "Focus solely on subjects where she excels."
                ],
                correctAnswer: 1
            },
            {
                question: "How can Alisha measure the success of her tutoring program?",
                options: [
                    "Ask for feedback from students and track their academic progress.",
                    "Ignore student feedback and continue with her methods.",
                    "Only celebrate students who improve dramatically.",
                    "Assess success based only on her own perspective."
                ],
                correctAnswer: 0
            }
        ]
    },
    {
        name: "VICTOR",
        image: "https://static.vecteezy.com/system/resources/previews/021/730/186/original/character-high-school-student-in-school-uniform-png.png",
        dialogue: "Victor is a tech enthusiast who wants to create an online platform to help students learn coding. He believes that everyone should have access to quality coding education regardless of their background.",
        questions: [
            {
                question: "What should Victor prioritize when developing his online coding platform?",
                options: [
                    "Create content that is accessible and engaging for beginners.",
                    "Focus solely on advanced coding techniques.",
                    "Limit access to only students from affluent backgrounds.",
                    "Make the platform too complicated to deter beginners."
                ],
                correctAnswer: 0
            },
            {
                question: "How can Victor ensure the sustainability of his platform?",
                options: [
                    "Seek partnerships with schools and organizations to promote his platform.",
                    "Stop updating the content after the initial launch.",
                    "Only rely on advertisements for income.",
                    "Ignore feedback from users about the platform."
                ],
                correctAnswer: 0
            }
        ]
    }
];

let currentCharacter = 0;
let currentQuestion = 0;
let score = 0;

const startScreen = document.getElementById('start-screen');
const quizContainer = document.getElementById('quiz-container');
const resultsScreen = document.getElementById('results-screen');
const startButton = document.getElementById('start-button');
const nextButton = document.getElementById('next-button');
const replayButton = document.getElementById('replay-button');
const characterImage = document.getElementById('character-image');
const dialogueBox = document.getElementById('dialogue-box');
const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');
const scoreDisplay = document.getElementById('score-display');

startButton.addEventListener('click', startQuiz);
nextButton.addEventListener('click', nextQuestion);
replayButton.addEventListener('click', restartQuiz);

function startQuiz() {
    startScreen.style.display = 'none';
    quizContainer.style.display = 'block';
    loadCharacter();
}

function loadCharacter() {
    const character = quizData[currentCharacter];
    characterImage.style.backgroundImage = `url(${character.image})`;
    dialogueBox.textContent = character.dialogue;
    loadQuestion();
}

function loadQuestion() {
    const character = quizData[currentCharacter];
    const question = character.questions[currentQuestion];
    questionText.textContent = question.question;
    optionsContainer.innerHTML = '';
    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.textContent = option;
        button.classList.add('option-button');
        button.addEventListener('click', () => selectAnswer(index));
        optionsContainer.appendChild(button);
    });
    nextButton.style.display = 'none';
}

function selectAnswer(selectedIndex) {
    const character = quizData[currentCharacter];
    const question = character.questions[currentQuestion];
    const buttons = optionsContainer.getElementsByTagName('button');
    
    for (let button of buttons) {
        button.disabled = true;
        if (Array.from(buttons).indexOf(button) === question.correctAnswer) {
            button.style.backgroundColor = 'green';
        }
    }
    
    if (selectedIndex === question.correctAnswer) {
        score++;
        buttons[selectedIndex].style.backgroundColor = 'green';
    } else {
        buttons[selectedIndex].style.backgroundColor = 'red';
    }
    
    nextButton.style.display = 'block';
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion >= quizData[currentCharacter].questions.length) {
        currentCharacter++;
        currentQuestion = 0;
        if (currentCharacter >= quizData.length) {
            showResults();
            return;
        }
        loadCharacter();
    } else {
        loadQuestion();
    }
}

function showResults() {
    quizContainer.style.display = 'none';
    resultsScreen.style.display = 'block';
    const totalQuestions = quizData.length * 2;
    scoreDisplay.textContent = `You scored ${score} out of ${totalQuestions}`;
}

function restartQuiz() {
    currentCharacter = 0;
    currentQuestion = 0;
    score = 0;
    resultsScreen.style.display = 'none';
    startScreen.style.display = 'block';
}
