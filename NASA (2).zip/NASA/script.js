document.addEventListener('DOMContentLoaded', function() {
    const animatedContent = document.getElementById('animated-content');
    const carouselImages = document.querySelectorAll('.image-carousel img');
    let currentImageIndex = 0;
    
    function fadeContent() {
        animatedContent.style.opacity = 0;
        setTimeout(() => {
            animatedContent.style.opacity = 1;
        }, 500);
    }

    function changeImage() {
        carouselImages[currentImageIndex].classList.remove('active');
        currentImageIndex = (currentImageIndex + 1) % carouselImages.length;
        carouselImages[currentImageIndex].classList.add('active');
    }

    // Initial fade in
    setTimeout(fadeContent, 1000);

    // Set interval for fading content every 5 seconds
    setInterval(fadeContent, 5000);

    // Set interval for changing images every 3 seconds
    setInterval(changeImage, 3000);

    // You can add more interactive elements or game logic here
});

window.addEventListener('scroll', function() {
    const slide1 = document.getElementById('slide1');
    const slide2 = document.getElementById('slide2');
    const slide3 = document.getElementById('slide3');
    const slide4 = document.getElementById('slide4');
    const scrollPosition = window.scrollY || window.pageYOffset;

    // Assuming each slide is 100vh, check when slide2 is in view
    if (scrollPosition >= window.innerHeight) {
        slide1.style.backgroundColor = '#5a5023'; // Change to slide2 color
    } else {
        slide1.style.backgroundColor = '#ffffff'; // Change back to slide1 color
    }
});

const button = document.getElementById('myButton');

button.addEventListener('mouseover', function() {
  this.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.5)';
});

button.addEventListener('mouseout', function() {
  this.style.boxShadow = 'none';
});