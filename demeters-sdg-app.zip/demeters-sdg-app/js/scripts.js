// SDG Data
const sdgData = [
    {
        id: 1,
        icon: "🚫",
        title: "No Poverty",
        description: "End poverty in all its forms everywhere. Everyone deserves a safe home and enough food to eat!"
    },
    {
        id: 2,
        icon: "🍎",
        title: "Zero Hunger",
        description: "End hunger and make sure everyone has nutritious food. No one should go to bed hungry!"
    },
    {
        id: 3,
        icon: "❤️",
        title: "Good Health and Well-being",
        description: "Ensure healthy lives and promote well-being for all. Everyone deserves to be healthy and happy!"
    },
    {
        id: 4,
        icon: "📚",
        title: "Quality Education",
        description: "Ensure inclusive and equitable quality education for all. Every child should have the chance to learn!"
    },
    {
        id: 5,
        icon: "⚖️",
        title: "Gender Equality",
        description: "Achieve gender equality and empower all women and girls. Everyone should be treated equally!"
    },
    {
        id: 6,
        icon: "💧",
        title: "Clean Water and Sanitation",
        description: "Ensure clean water and sanitation for all. Clean water is essential for life!"
    },
    {
        id: 7,
        icon: "⚡",
        title: "Affordable and Clean Energy",
        description: "Ensure access to affordable, reliable, and clean energy. Power our world sustainably!"
    },
    {
        id: 8,
        icon: "💼",
        title: "Decent Work and Economic Growth",
        description: "Promote sustained economic growth and decent work for all. Everyone deserves a good job!"
    },
    {
        id: 9,
        icon: "🏗️",
        title: "Industry, Innovation and Infrastructure",
        description: "Build resilient infrastructure and promote innovation. Let's build a better future!"
    },
    {
        id: 10,
        icon: "📊",
        title: "Reduced Inequalities",
        description: "Reduce inequality within and among countries. Fairness for everyone, everywhere!"
    },
    {
        id: 11,
        icon: "🏙️",
        title: "Sustainable Cities and Communities",
        description: "Make cities inclusive, safe, and sustainable. Let's build amazing communities!"
    },
    {
        id: 12,
        icon: "♻️",
        title: "Responsible Consumption and Production",
        description: "Ensure sustainable consumption and production patterns. Use resources wisely!"
    },
    {
        id: 13,
        icon: "🌍",
        title: "Climate Action",
        description: "Take urgent action to combat climate change. Let's protect our planet!"
    },
    {
        id: 14,
        icon: "🐟",
        title: "Life Below Water",
        description: "Conserve and sustainably use oceans and marine resources. Protect our ocean friends!"
    },
    {
        id: 15,
        icon: "🌳",
        title: "Life on Land",
        description: "Protect, restore and promote sustainable use of terrestrial ecosystems. Save our forests and animals!"
    },
    {
        id: 16,
        icon: "🕊️",
        title: "Peace, Justice and Strong Institutions",
        description: "Promote peaceful and inclusive societies. Let's work together in peace!"
    },
    {
        id: 17,
        icon: "🤝",
        title: "Partnerships for the Goals",
        description: "Strengthen global partnerships for sustainable development. Together we can do anything!"
    }
];

// Quiz Questions
const quizQuestions = [
    {
        question: "Which SDG focuses on making sure everyone has enough food to eat?",
        options: ["No Poverty", "Zero Hunger", "Clean Water", "Quality Education"],
        correct: 1,
        explanation: "Zero Hunger (SDG 2) aims to end hunger and ensure everyone has access to nutritious food!"
    },
    {
        question: "What does SDG 6 focus on?",
        options: ["Clean Energy", "Clean Water and Sanitation", "Climate Action", "Quality Education"],
        correct: 1,
        explanation: "SDG 6 focuses on ensuring clean water and sanitation for everyone around the world!"
    },
    {
        question: "Which SDG is about protecting our oceans and sea life?",
        options: ["Life on Land", "Life Below Water", "Climate Action", "Clean Energy"],
        correct: 1,
        explanation: "Life Below Water (SDG 14) is all about protecting our oceans and the amazing creatures that live there!"
    },
    {
        question: "How many Sustainable Development Goals are there in total?",
        options: ["15", "17", "20", "12"],
        correct: 1,
        explanation: "There are 17 Sustainable Development Goals that countries around the world are working on together!"
    },
    {
        question: "Which SDG focuses on making sure all children can go to school?",
        options: ["Quality Education", "No Poverty", "Gender Equality", "Good Health"],
        correct: 0,
        explanation: "Quality Education (SDG 4) ensures that every child has the opportunity to learn and go to school!"
    },
    {
        question: "What is the main goal of SDG 13?",
        options: ["Reduce pollution", "Climate Action", "Save animals", "Build cities"],
        correct: 1,
        explanation: "Climate Action (SDG 13) focuses on taking urgent action to combat climate change and its impacts!"
    }
];

// Game State
let gameState = {
    currentQuestionIndex: 0,
    score: 0,
    totalQuestions: quizQuestions.length,
    completedActivities: new Set(),
    progress: 0
};

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    generateSDGGrid();
    updateProgress();
});

function initializeApp() {
    // Load saved progress from localStorage
    const savedProgress = localStorage.getItem('demetersProgress');
    if (savedProgress) {
        gameState.completedActivities = new Set(JSON.parse(savedProgress));
        calculateProgress();
    }
}

function setupEventListeners() {
    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                // Close mobile menu if open
                if (navMenu) {
                    navMenu.classList.remove('active');
                }
            }
        });
    });
}

function generateSDGGrid() {
    const sdgGrid = document.getElementById('sdgGrid');
    if (!sdgGrid) return;

    sdgGrid.innerHTML = '';
    
    sdgData.forEach(sdg => {
        const sdgCard = document.createElement('div');
        sdgCard.className = 'sdg-card';
        sdgCard.innerHTML = `
            <span class="sdg-icon">${sdg.icon}</span>
            <h3>${sdg.title}</h3>
            <p>${sdg.description}</p>
        `;
        
        sdgCard.addEventListener('click', () => {
            showSDGDetails(sdg);
        });
        
        sdgGrid.appendChild(sdgCard);
    });
}

function showSDGDetails(sdg) {
    alert(`🌟 SDG ${sdg.id}: ${sdg.title}\n\n${sdg.description}\n\nDid you know? This goal helps make our world a better place for everyone!`);
}

function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Quiz Functions
function startQuiz() {
    gameState.currentQuestionIndex = 0;
    gameState.score = 0;
    document.getElementById('quizModal').style.display = 'block';
    showQuestion();
}

function showQuestion() {
    const question = quizQuestions[gameState.currentQuestionIndex];
    const questionElement = document.getElementById('quizQuestion');
    const optionsElement = document.getElementById('quizOptions');
    const resultElement = document.getElementById('quizResult');
    
    questionElement.innerHTML = `<strong>Question ${gameState.currentQuestionIndex + 1}:</strong> ${question.question}`;
    
    optionsElement.innerHTML = '';
    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.className = 'quiz-option';
        button.textContent = option;
        button.onclick = () => selectAnswer(index);
        optionsElement.appendChild(button);
    });
    
    resultElement.innerHTML = '';
    document.getElementById('nextQuestionBtn').style.display = 'none';
    document.getElementById('finishQuizBtn').style.display = 'none';
}

function selectAnswer(selectedIndex) {
    const question = quizQuestions[gameState.currentQuestionIndex];
    const options = document.querySelectorAll('.quiz-option');
    const resultElement = document.getElementById('quizResult');
    
    // Disable all options
    options.forEach(option => option.disabled = true);
    
    // Show correct/incorrect styling
    options[question.correct].classList.add('correct');
    if (selectedIndex !== question.correct) {
        options[selectedIndex].classList.add('incorrect');
    }
    
    // Update score and show result
    if (selectedIndex === question.correct) {
        gameState.score++;
        resultElement.innerHTML = `<div class="result-correct">🎉 Correct! ${question.explanation}</div>`;
    } else {
        resultElement.innerHTML = `<div class="result-incorrect">❌ Not quite right. ${question.explanation}</div>`;
    }
    
    // Show next button
    if (gameState.currentQuestionIndex < gameState.totalQuestions - 1) {
        document.getElementById('nextQuestionBtn').style.display = 'block';
    } else {
        document.getElementById('finishQuizBtn').style.display = 'block';
    }
}

function nextQuestion() {
    gameState.currentQuestionIndex++;
    showQuestion();
}

function finishQuiz() {
    const percentage = Math.round((gameState.score / gameState.totalQuestions) * 100);
    let message = `🎊 Quiz Complete!\n\nYou scored ${gameState.score} out of ${gameState.totalQuestions} (${percentage}%)\n\n`;
    
    if (percentage >= 80) {
        message += "🌟 Excellent! You're an SDG superstar!";
    } else if (percentage >= 60) {
        message += "👍 Great job! Keep learning about the SDGs!";
    } else {
        message += "💪 Good effort! Try again to learn more!";
    }
    
    alert(message);
    gameState.completedActivities.add('quiz');
    updateProgress();
    closeQuiz();
}

function closeQuiz() {
    document.getElementById('quizModal').style.display = 'none';
}

// Match Game Functions
function startMatchGame() {
    document.getElementById('matchModal').style.display = 'block';
    setupMatchGame();
}

function setupMatchGame() {
    // Select 5 random SDGs for the match game
    const selectedSDGs = sdgData.slice(0, 5);
    
    const iconsContainer = document.getElementById('matchIcons');
    const descriptionsContainer = document.getElementById('matchDescriptions');
    
    iconsContainer.innerHTML = '';
    descriptionsContainer.innerHTML = '';
    
    // Shuffle descriptions
    const shuffledDescriptions = [...selectedSDGs].sort(() => Math.random() - 0.5);
    
    selectedSDGs.forEach((sdg, index) => {
        const iconDiv = document.createElement('div');
        iconDiv.className = 'match-item';
        iconDiv.innerHTML = `<div style="font-size: 2rem;">${sdg.icon}</div><div><strong>${sdg.title}</strong></div>`;
        iconDiv.dataset.id = sdg.id;
        iconDiv.onclick = () => selectMatchItem(iconDiv, 'icon');
        iconsContainer.appendChild(iconDiv);
    });
    
    shuffledDescriptions.forEach((sdg, index) => {
        const descDiv = document.createElement('div');
        descDiv.className = 'match-item';
        descDiv.innerHTML = `<div>${sdg.description}</div>`;
        descDiv.dataset.id = sdg.id;
        descDiv.onclick = () => selectMatchItem(descDiv, 'description');
        descriptionsContainer.appendChild(descDiv);
    });
    
    document.getElementById('matchResult').innerHTML = '';
}

let selectedIcon = null;
let selectedDescription = null;

function selectMatchItem(element, type) {
    // Remove previous selections of the same type
    if (type === 'icon') {
        if (selectedIcon) selectedIcon.classList.remove('selected');
        selectedIcon = element;
    } else {
        if (selectedDescription) selectedDescription.classList.remove('selected');
        selectedDescription = element;
    }
    
    element.classList.add('selected');
    
    // Check if both are selected and match
    if (selectedIcon && selectedDescription) {
        if (selectedIcon.dataset.id === selectedDescription.dataset.id) {
            selectedIcon.classList.add('matched');
            selectedDescription.classList.add('matched');
            selectedIcon.classList.remove('selected');
            selectedDescription.classList.remove('selected');
            selectedIcon = null;
            selectedDescription = null;
        }
    }
}

function checkMatches() {
    const matchedItems = document.querySelectorAll('.match-item.matched');
    const totalItems = document.querySelectorAll('.match-item').length / 2;
    const matchedPairs = matchedItems.length / 2;
    
    const resultDiv = document.getElementById('matchResult');
    
    if (matchedPairs === totalItems) {
        resultDiv.innerHTML = '<div class="result-correct">🎉 Perfect! You matched all the SDGs correctly!</div>';
        gameState.completedActivities.add('match');
        updateProgress();
    } else {
        resultDiv.innerHTML = `<div class="result-incorrect">You matched ${matchedPairs} out of ${totalItems} pairs. Keep trying!</div>`;
    }
}

function closeMatchGame() {
    document.getElementById('matchModal').style.display = 'none';
    selectedIcon = null;
    selectedDescription = null;
}

// Puzzle Game (Simple implementation)
function startPuzzle() {
    const puzzleMessages = [
        "🌍 Together we can make the world a better place!",
        "🤝 When we work together, amazing things happen!",
        "🌟 Every small action counts towards the SDGs!",
        "💚 Protecting our planet is everyone's responsibility!"
    ];
    
    const randomMessage = puzzleMessages[Math.floor(Math.random() * puzzleMessages.length)];
    
    setTimeout(() => {
        alert(`🧩 Puzzle Complete!\n\n${randomMessage}\n\nGreat job solving the SDG puzzle!`);
        gameState.completedActivities.add('puzzle');
        updateProgress();
    }, 1000);
}

// Progress Functions
function calculateProgress() {
    const totalActivities = 3; // quiz, match, puzzle
    gameState.progress = (gameState.completedActivities.size / totalActivities) * 100;
}

function updateProgress() {
    calculateProgress();
    
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    const starsContainer = document.getElementById('starsContainer');
    
    if (progressFill) {
        progressFill.style.width = gameState.progress + '%';
    }
    
    if (progressText) {
        progressText.textContent = Math.round(gameState.progress) + '% Complete';
    }
    
    if (starsContainer) {
        const starCount = Math.floor(gameState.progress / 20); // 1 star per 20%
        starsContainer.innerHTML = '⭐'.repeat(starCount);
    }
    
    // Save progress
    localStorage.setItem('demetersProgress', JSON.stringify([...gameState.completedActivities]));
    
    // Show celebration for 100% completion
    if (gameState.progress === 100) {
        setTimeout(() => {
            alert("🎊 Congratulations! You've completed all the SDG activities!\n\nYou're now an official SDG Champion! 🏆\n\nKeep spreading the word about sustainable development!");
        }, 500);
    }
}

// Close modals when clicking outside
window.onclick = function(event) {
    const quizModal = document.getElementById('quizModal');
    const matchModal = document.getElementById('matchModal');
    
    if (event.target === quizModal) {
        closeQuiz();
    }
    if (event.target === matchModal) {
        closeMatchGame();
    }
}

// Add some fun animations and interactions
function addSparkleEffect(element) {
    element.style.position = 'relative';
    element.style.overflow = 'hidden';
    
    const sparkle = document.createElement('div');
    sparkle.innerHTML = '✨';
    sparkle.style.position = 'absolute';
    sparkle.style.top = Math.random() * 100 + '%';
    sparkle.style.left = Math.random() * 100 + '%';
    sparkle.style.animation = 'sparkle 1s ease-out forwards';
    
    element.appendChild(sparkle);
    
    setTimeout(() => {
        sparkle.remove();
    }, 1000);
}

// Add sparkle animation to CSS dynamically
const sparkleStyle = document.createElement('style');
sparkleStyle.textContent = `
    @keyframes sparkle {
        0% {
            opacity: 0;
            transform: scale(0) rotate(0deg);
        }
        50% {
            opacity: 1;
            transform: scale(1) rotate(180deg);
        }
        100% {
            opacity: 0;
            transform: scale(0) rotate(360deg);
        }
    }
`;
document.head.appendChild(sparkleStyle);

// Add sparkle effects to completed activities
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('game-button') || e.target.classList.contains('cta-button')) {
        addSparkleEffect(e.target.parentElement);
    }
});

// Fun fact generator
const funFacts = [
    "🌍 The SDGs were adopted by all 193 UN Member States in 2015!",
    "🎯 The SDGs aim to be achieved by 2030 - that's why they're also called the 2030 Agenda!",
    "🌈 The SDGs are interconnected - progress in one goal helps achieve others!",
    "👥 The SDGs were created with input from millions of people around the world!",
    "🔄 The SDGs replace the earlier Millennium Development Goals (MDGs)!",
    "🌟 Young people like you are key to achieving the SDGs!"
];

function showRandomFact() {
    const randomFact = funFacts[Math.floor(Math.random() * funFacts.length)];
    alert(`💡 Fun SDG Fact!\n\n${randomFact}`);
}

// Add a fun fact button (you can call this function anywhere)
console.log("🌟 Demeters SDG App loaded successfully! Type 'showRandomFact()' in the console for a fun SDG fact!");

// Easter egg - Konami code for extra fun
let konamiCode = [];
const konamiSequence = [38, 38, 40, 40, 37, 39, 37, 39, 66, 65]; // Up Up Down Down Left Right Left Right B A

document.addEventListener('keydown', function(e) {
    konamiCode.push(e.keyCode);
    if (konamiCode.length > konamiSequence.length) {
        konamiCode.shift();
    }
    
    if (konamiCode.join(',') === konamiSequence.join(',')) {
        document.body.style.animation = 'rainbow 2s infinite';
        alert("🌈 Easter Egg Activated! You found the secret SDG rainbow mode! 🦄");
        
        // Add rainbow animation
        const rainbowStyle = document.createElement('style');
        rainbowStyle.textContent = `
            @keyframes rainbow {
                0% { filter: hue-rotate(0deg); }
                100% { filter: hue-rotate(360deg); }
            }
        `;
        document.head.appendChild(rainbowStyle);
        
        setTimeout(() => {
            document.body.style.animation = '';
        }, 10000);
    }
});

