# Demeters - SDG Gamified Web App

## Project Summary

**Demeters** is a child-friendly educational web application designed to teach the **United Nations Sustainable Development Goals (SDGs)** through engaging and gamified content. It targets kids aged 8 to 14, offering a colorful, playful, and interactive learning experience.

## Features

*   **Homepage:** Introduces SDGs with child-friendly explanations and displays all 17 SDGs with icons and brief descriptions.
*   **Mini-Games/Quiz Modules:** Includes interactive games like an SDG Quiz Challenge and a Match the Goals game to reinforce learning.
*   **Progress Tracker:** Visual element (progress bar and stars) to track the user's learning journey.
*   **Responsive Design:** Works seamlessly on both desktop and mobile browsers.
*   **Clean Code:** Well-commented HTML, CSS, and JavaScript for easy understanding and maintenance.

## Folder Structure

```
demeters-sdg-app/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── scripts.js
└── assets/
    └── (for images and icons - currently placeholders)
└── README.md
```

## How to Run the Project Locally

1.  **Download or Clone:** Download this repository as a ZIP file and unzip it, or clone it using Git:
    ```bash
    git clone <repository-url>
    ```
2.  **Navigate to Project Directory:** Open your terminal or command prompt and navigate to the `demeters-sdg-app` directory:
    ```bash
    cd demeters-sdg-app
    ```
3.  **Open `index.html`:** Simply open the `index.html` file in your preferred web browser. You can do this by double-clicking the file or by dragging it into your browser window.

    Alternatively, you can use a local web server (e.g., Live Server VS Code extension) for a better development experience.

## How to Deploy on GitHub Pages

1.  **Create a New GitHub Repository:** Go to GitHub and create a new public repository (e.g., `demeters-sdg-app`). **Do NOT initialize it with a README, .gitignore, or license.**
2.  **Upload Files:**
    *   **Option A (GitHub Desktop/Git CLI):** If you have Git installed, navigate to your project directory in the terminal and run:
        ```bash
        git init
        git add .
        git commit -m "Initial commit: Demeters SDG App"
        git branch -M main
        git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
        git push -u origin main
        ```
    *   **Option B (Manual Upload):** On your new GitHub repository page, click on "uploading an existing file" and drag and drop all the files and folders (css, js, assets, index.html, README.md) from your local `demeters-sdg-app` directory into the browser window. Commit the changes.
3.  **Enable GitHub Pages:**
    *   Go to your repository on GitHub.
    *   Click on **Settings** (usually near the top right).
    *   In the left sidebar, click on **Pages**.
    *   Under "Build and deployment", for "Source", select **Deploy from a branch**.
    *   For "Branch", select `main` (or `master` if that's what you used) and choose the `/ (root)` folder.
    *   Click **Save**.
4.  **Access Your Live Site:** GitHub Pages will build and deploy your site. This usually takes a few minutes. Once deployed, the URL will be displayed on the GitHub Pages settings page (e.g., `https://YOUR_USERNAME.github.io/YOUR_REPOSITORY_NAME/`). Share this link in your resume/portfolio!

